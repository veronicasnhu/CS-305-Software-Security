package com.snhu.sslserver;

import java.security.MessageDigest;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@SpringBootApplication
@RestController
public class SslServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SslServerApplication.class, args);
	}

	@GetMapping("/hash")
	public String getHash() throws Exception {
		String data = "Veronica SNHU Project Two";

		MessageDigest md = MessageDigest.getInstance("SHA-256");
		byte[] bytes = md.digest(data.getBytes());

		String checksum = "";
		for (byte b : bytes) {
			checksum = checksum + String.format("%02x", b);
		}

		return "Name: Veronica<br>Data: " + data + "<br>Checksum: " + checksum;
	}
}